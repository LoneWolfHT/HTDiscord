local vote_running = false
local staff = {"Lone_Wolf", "ynomrah", "IMS_BULLDOGS", "GreenDimond", "ChimneySwift", "ExeterDad", "Kibbie", "mcg", "kiko", "DrClaw", "monkeybutt", "darianbrown", "darkturretyt", "CrimsonRed", "octacian", "Sky_Fall_II"}
local name = "panic!"

minetest.register_on_receiving_chat_messages(function(msg)
    local message = minetest.strip_colors(msg)
    local result = "danger"
    message = string.lower(msg)

    if message:find("[vote]") and message:find("use the csm") then
        if msg:find("<") and msg:find(">") then
            name = msg:sub(msg:find("<")+1, msg:find(">")-1)
            vote_running = true
            for check in pairs(staff) do
                if name == staff[check] then
                    result = "ok"
                end
            end
            if result ~= "ok" then
                name = "panic!"
            end
        end
    end
end)

minetest.register_chatcommand("v", {
    description = "Vote on a pending vote: .vote <yes/y|no/n>",
    func = function(param)
    local votetype = autofill(param)

    if vote_running == true and name ~= "panic!" then
        vote_running = false
        if votetype == "yes" or votetype == "y" then
            minetest.run_server_chatcommand("msg", name.." vote, yes")
        elseif votetype == "no" or votetype == "n" then
            minetest.run_server_chatcommand("msg", name.." vote, no")
        else
            minetest.display_chat_message(minetest.colorize("red", "[ERROR]").." Invalid vote type.")
        end
    else
        minetest.display_chat_message(minetest.colorize("red", "[ERROR]").." No vote running or the vote was issued by the wrong player")
    end
end
})