local can_cast = true
local wands_enabled = false
local muted = false
local player
local playername
local player_name
local incoming_spell
local spelltimeout = 5

local spells = {
	kill = "kust",
	mute = "bedeng",
	poison = "axu",
	disarm = "bekem",
	view = "ditini",
	tp = "ber",
	barki = {
		escape = {spell = "rev", param = "/spawn"},
	},
}

minetest.register_on_connect(function()
	player = minetest.localplayer
	playername = string.lower(player:get_name())
	player_name = player:get_name()
end)

minetest.after(1, function() minetest.display_chat_message(minetest.colorize("red", "[WANDS] ").."Currently disabled. Run '.wands t' to toggle state") end)

--
--Fun stuff
--

local function is_in_range(name)
	for k, v in pairs(minetest.get_player_names()) do
		if v:lower() == name:lower() then
			return(true)
		end
	end

	return(false)
end

local function apply_effect(name)
	if wands_enabled == false then return end

	if name == "kust" and incoming_spell == "kust" then
		minetest.run_server_chatcommand("killme", "")
	elseif name == "bedeng" and incoming_spell == "bedeng" then
		local random = math.random(1, 3)

		if random == 1 then
			minetest.send_chat_message("Oh no. I've been muted D:")
		elseif random == 2 then
			minetest.send_chat_message(":x")
		else
			minetest.send_chat_message("*zip*")
		end

		muted = true
		minetest.after(5, function() minetest.send_chat_message("I can cast spells again! >:)") muted = false end)

	elseif name == "axu" and incoming_spell == "axu" then
		for i = 4, 12, 4 do
			minetest.after(i, function() minetest.run_server_chatcommand("killme", "") end)
		end
	elseif name == "bekem" and incoming_spell == "bekem" then
		local wield = minetest.get_wielded_item()

		if wield:get_name():find("stick") then
			minetest.run_server_chatcommand("pulverize", "")
			minetest.send_chat_message("noo, my wand :(")
		end
	elseif name == "ditini" and incoming_spell == "ditini" then
		minetest.send_chat_message("augh, my view flipped around!")
		if minetest.camera:get_camera_mode() == 2 then
			minetest.camera:set_camera_mode(1)
		else
			minetest.camera:set_camera_mode(2)
		end
	elseif name == "ber" and incoming_spell == "ber" then
		minetest.run_server_chatcommand("tpy", "")
	end

	incoming_spell = false
end

local function cast_spell(spell, victim)
	if can_cast == false then return end

	if spell:find("ber") then
		minetest.run_server_chatcommand("tpr", victim)
	end

	can_cast = false
	minetest.after(spelltimeout, function() can_cast = true end)
	minetest.send_chat_message(minetest.colorize("cyan", "eris "..spell.." "..victim))
end

minetest.register_on_receiving_chat_messages(function(message)
	local msg = minetest.strip_colors(message)
	local name = ""

	if msg:sub(1, 1) == "<" and msg:find(">") then
		name = msg:sub(2, msg:find(">")-1)
	else
		return(false)
	end

	msg = msg:sub(msg:find(">")+2)

	if msg:find(player_name) and msg:find("eris ") and wands_enabled == true then
		local mesg = msg:sub(6)
		local spell = mesg:sub(1, mesg:find(" ")-1)

		for k, v in pairs(spells) do
			if k ~= "barki" and spell == v and is_in_range(name) == true then
				incoming_spell = v
				minetest.after(spelltimeout, function()
					apply_effect(v)
				end)
				minetest.display_chat_message("<"..name.."> "..minetest.colorize("cyan", "eris "..spell.." "..player_name.."!!!"))
				return(true)
			end
		end
	end
	
	if msg:find("deste ") and wands_enabled == true then
		local spell = msg:sub(7)

		minetest.display_chat_message("<"..name.."> "..minetest.colorize("#00FF00", "deste "..spell.."!!!"))
		return(true)
	end

	if msg:find("barki ") and wands_enabled == true then
		local spell = msg:sub(7)
		minetest.display_chat_message("<"..name.."> "..minetest.colorize("yellow", "barki "..spell.."!!!"))
		return(true)
	end

	return(false)
end)

minetest.register_on_sending_chat_messages(function(message)
	local item = minetest.get_wielded_item()

	local msg = string.lower(minetest.strip_colors(message))

	if msg:find("eris ") and can_cast == true and muted == false and item:get_name():find("stick") ~= nil and wands_enabled == true then
		local msg = msg:sub(6)

		if not msg:find(" ") then return(false) end

		local spell = msg:sub(1, msg:find(" ")-1)
		local victim = msg:sub(msg:find(" ")+1)


		for k, v in pairs(spells) do
			if k ~= "barki" and spell == v and is_in_range(victim) == true then
				cast_spell(spell, victim)
				return(true)
			end
		end
	elseif msg:find("eris ") then
		return(true)
	end
	
	if msg:find("deste ") and muted == false and can_cast == true and item:get_name():find("stick") ~= nil and wands_enabled == true then
		local spell = msg:sub(7)

		if incoming_spell == spell then
			incoming_spell = false
			minetest.send_chat_message(minetest.colorize("#00FF00", "deste "..spell))
			return(true)
		end
	elseif msg:find("deste ") then
		return(true)
	end

	if msg:find("barki ") and muted == false and can_cast == true and item:get_name():find("stick") ~= nil and wands_enabled == true then
		local spell = msg:sub(7)

		for k, v in pairs(spells.barki) do
			if v.spell == spell then
				minetest.send_chat_message(v.param)
				minetest.send_chat_message(minetest.colorize("yellow", "barki "..spell))
				return(true)
			end
		end
	end

	if msg:find("derxistin") and muted == false and can_cast == true and item:get_name():find("stick") ~= nil and wands_enabled == true then
		minetest.after(2, function()
			for i = 0, 2, 1 do
				minetest.after(i*2, function() minetest.send_chat_message(tostring(3-i)) end)
			end
			minetest.after(6, function() minetest.send_chat_message("Go") end)
		end)
	end

	return(false)
end)

minetest.register_chatcommand("wands", {
    description = "Show an explanation of the wands CSM",
    func = function(param)
    	if param:find("spells") then
    		for k, v in pairs(spells) do
    			if k ~= "barki" then
    				minetest.display_chat_message(minetest.colorize("cyan", "- "..k..": '"..v.."'"))
    			end
    		end

    		minetest.display_chat_message(minetest.colorize("cyan", "[Barki Spells]"))

    		for k, v in pairs(spells.barki) do
    			minetest.display_chat_message(minetest.colorize("cyan", "- "..k..": '"..v.spell.."'"))
    		end

    		minetest.display_chat_message(minetest.colorize("cyan", "Countdown (3-0) - derxistin"))
    	elseif param:find("t") then
    		if wands_enabled == false then
    			wands_enabled = true
    			minetest.display_chat_message(minetest.colorize("#00FF00", "[WANDS] Enabled. Have fun!"))
    		else
    			minetest.display_chat_message(minetest.colorize("red", "[WANDS] Disabled. Come back soon!"))
    			wands_enabled = false
    		end
    	else
        	minetest.display_chat_message(minetest.colorize("cyan", "Spells are made up of 2-3 words. The first word is the spell action. There are only 2 right know. barki, eris and deste. Or move, attack and block.\nThe second word is the spell effect. Run '.wands spells' to see a list of effects.\nThe third word is only needed if the spell action is 'kust' (attack). This word must be the name of the player you are casting the spell at. If you can't see their nametag ingame then the spell will fail.\n'eris kust Lone' will cast a killing spell at the player Lone. Lone must then send 'deste kust' to block that killing spell.\nYou can use the barki action to teleport to places. 'barki rev' will teleport you to the spawnpoint"))
        end
    end
})