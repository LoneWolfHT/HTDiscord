local can_cast = true
local muted = false
local player
local playername
local player_name
local incoming_spell
local spelltimeout = 3.5

local spells = {
	kill = "kustin",
	mute = "bedeng",
	poison = "axu"
}

minetest.register_on_connect(function()
	player = minetest.localplayer
	playername = string.lower(player:get_name())
	player_name = player:get_name()
end)

--
--Fun stuff
--

local function is_in_range(name)
	for k, v in pairs(minetest.get_player_names()) do
		minetest.log(dump(v).."  "..dump(name))
		if v == name then
			return(true)
		end
	end

	return(false)
end

local function apply_effect(name)
	if name == "kill" and incoming_spell == "kustin" then
		minetest.run_server_chatcommand("killme", "")
	elseif name == "mute" and incoming_spell == "bedeng" then
		local random = math.random(1, 3)

		if random == 1 then
			minetest.send_chat_message("Augh. I've been muted D:")
		elseif random == 2 then
			minetest.send_chat_message(":x")
		else
			minetest.send_chat_message("*zip*")
		end

		muted = true
		minetest.after(5, function() muted = false end)

	elseif name == "poison" and incoming_spell == "axu" then
		for i = 0, 6, 2 do
			minetest.after(i, function() minetest.run_server_chatcommand("killme", "") end)
		end
	end
end

local function cast_spell(spell, victim)
	if can_cast == false then return end

	can_cast = false
	minetest.after(spelltimeout, function() can_cast = true end)
	minetest.send_chat_message(minetest.colorize("cyan", "eris "..spell.." "..victim))
end

minetest.register_on_receiving_chat_messages(function(message)
	local msg = minetest.strip_colors(message)
	local name = ""

	if msg:sub(1, 1) == "<" and msg:find(">") then
		name = msg:sub(2, msg:find(">")-1)
	else
		return(false)
	end

	msg = msg:sub(msg:find(">")+2)

	if msg:find(player_name) and msg:find("eris ") then
		local mesg = msg:sub(6)
		local spell = mesg:sub(1, mesg:find(" ")-1)

		for k, v in pairs(spells) do
			if spell == v and is_in_range(name) == true then
				incoming_spell = v
				minetest.after(spelltimeout, function()
					apply_effect(k)
				end)
				minetest.display_chat_message("<"..name.."> "..minetest.colorize("cyan", "eris "..spell.." "..player_name))
				return(true)
			end
		end
	end
	
	if msg:find("deste ") then
		local spell = msg:sub(7)

		minetest.display_chat_message("<"..name.."> "..minetest.colorize("#00FF00", "deste "..spell))
		return(true)
	end

	return(false)
end)

minetest.register_on_sending_chat_messages(function(message)
	local item = minetest.get_wielded_item()

	if not item:get_name():find("stick") then
		return(false)
	end

	local msg = string.lower(minetest.strip_colors(message))

	if msg:find("eris ") and can_cast == true and muted == false then
		local msg = msg:sub(6)
		local spell = msg:sub(1, msg:find(" ")-1)
		local victim = msg:sub(msg:find(" ")+1)


		for k, v in pairs(spells) do
			if spell == v and is_in_range(victim) == true then
				cast_spell(spell, victim)
				return(true)
			end
		end
	elseif msg:find("eris ") then
		return(true)
	end
	
	if msg:find("deste ") and muted == false and can_cast == true then
		local spell = msg:sub(7)

		if incoming_spell == spell then
			incoming_spell = false
			minetest.send_chat_message(minetest.colorize("#00FF00", "deste "..spell))
			return(true)
		end
	elseif msg:find("deste ") then
		return(true)
	end

	return(false)
end)

minetest.register_chatcommand("wands", {
    description = "Show an explanation of the wands CSM",
    func = function(param)
    	if param:find("spells") then
    		for k, v in pairs(spells) do
    			minetest.display_chat_message(minetest.colorize("cyan", "- "..k..": '"..v.."'"))
    		end
    	else
        	minetest.display_chat_message(minetest.colorize("cyan", "Spells are made up of 2-3 words. The first word is the spell action. There are only 2 right know. kustin and deste. Or attack and block.\nThe second word is the spell effect. Run '.wands spells' to see a list of effects.\nThe third word is only needed if the spell action is 'kustin' (attack). This word must be the name of the player you are casting the spell at. If you can't see their nametag ingame then the spell will fail.\n'eris kustin Lone' will cast a killing spell at the player Lone. Lone must then send 'deste kustin' to block that killing spell"))
        end
    end
})