local can_cast = true
local muted = false
local player
local playername
local player_name
local incoming_spell
local spelltimeout = 3.5

local spells = {
	kill = "kustin",
	mute = "bedeng",
	poison = "axu"
}

minetest.register_on_connect(function()
	player = minetest.localplayer
	playername = string.lower(player:get_name())
	player_name = player:get_name()
end)

--
--Fun stuff
--

local function is_in_range(name)
	for k, v in pairs(minetest.get_player_names()) do
		if v == name then
			return true
		end
	end

	return(false)
end

local function apply_effect(name)
	if name == "kill" and incoming_spell == "kustin" then
		minetest.run_server_chatcommand("killme", "")
	elseif name == "mute" and incoming_spell == "bedeng" then
		muted = true
		minetest.after(5, function() muted = false end)
	elseif name == "poison" and incoming_spell == "axu" then
		for i = 0, 4, 1 do
			minetest.after(i, function() minetest.run_server_chatcommand("killme", "") end)
		end
	end
end

local function cast_spell(spell, victim)
	minetest.send_chat_message(minetest.colorize("cyan", "eris "..spell.." "..victim))
end

minetest.register_on_receiving_chat_messages(function(message)
	local msg = minetest.strip_colors(message)
	local name = ""

	if msg:sub(1, 1) == "<" and msg:find(">") then
		name = msg:sub(2, msg:find(">")-1)
	else
		return(false)
	end

	msg = string.lower(msg):sub(string.lower(msg):find(">")+2)

	if msg:find(playername) and msg:find("eris ") then
		local msg = msg:sub(6)
		local spell = msg:sub(1, msg:find(" ")-1)

		for k, v in pairs(spells) do
			if spell == v then
				incoming_spell = v
				minetest.after(spelltimeout, function()
					apply_effect(k)
				end)

				minetest.display_chat_message("<"..name.."> "..minetest.colorize("cyan", "eris "..spell.." "..player_name))
				return(true)
			end
		end
	end
	
	if msg:find(playername) and msg:find("deste ") then
		local spell = msg:sub(7)

		minetest.display_chat_message("<"..name.."> "..minetest.colorize("#00FF00", "deste "..spell))
		return(true)
	end

	return(false)
end)

minetest.register_on_sending_chat_messages(function(message)
	local item = minetest.get_wielded_item()
	if not item:get_name():find("stick") then
		return(false)
	end

	local msg = string.lower(minetest.strip_colors(message))

	minetest.log(dump(msg))

	if msg:find("eris ") and can_cast == true and muted == false then
		local msg = msg:sub(6)
		local spell = msg:sub(1, msg:find(" ")-1)
		local victim = msg:sub(msg:find(" ")+1)

		for k, v in pairs(spells) do
			if spell == v and is_in_range(victim) then
				cast_spell(spell, victim)
				return(true)
			end
		end
	end
	
	if msg:find("deste ") and muted == false and can_cast == true then
		local spell = msg:sub(7)

		if incoming_spell == spell then
			incoming_spell = false
			minetest.send_chat_message(minetest.colorize("#00FF00", "deste "..spell))
			return(true)
		end
	end

	return(false)
end)